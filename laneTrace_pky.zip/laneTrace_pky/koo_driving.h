#include <stdio.h>
#include "car_lib.h"

double distance_calculate(int data);
int distance_sensor();
void passing_go_back();
void passing_left();
void passing_right();
